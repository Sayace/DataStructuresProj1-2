package project2;
/**
 * The color class stores a color's hexadecimal value, name, and RGB values
 * Also has constructors, getters, and override methods that deal with a color's
 * information
 * 
 * @author Alice Han
 *
 */

public class Color implements Comparable<Color>{
	//initialized private variables that will be used throughout the class
	private String colorHexValue = null;
	private String colorName = null;
	private int red, green, blue;
	/**
	 * Creates a Color object and checks to see if it passed a valid hexadecimal value
	 * and if it is valid the constructor sets valid hexadecimal values as the object's hex value
	 * 
	 * @param colorHexValue a string in the format of #XXXXXX where X represents a digit or letter between A and F
	 * @throws IllegalArgumentException exception is thrown when passed an invalid hexadecimal value
	 */
	public Color ( String colorHexValue ) throws IllegalArgumentException{
		//checks if the color's hexadecimal value string is length 7 and starts with a #
		if (colorHexValue.length()!=7 || colorHexValue.charAt(0)!='#') {
			throw new IllegalArgumentException("This is an invalid hexadecimal value.");
		}
		//iterates through the hexadecimal value to check if the values are valid
		for (int i=1; i<7; i++) {
			if (Character.isDigit(colorHexValue.charAt(i))) {
				continue;
			}
			else if (Character.isLetter(colorHexValue.charAt(i))) {
				if ((colorHexValue.charAt(i)>='A' && colorHexValue.charAt(i) <= 'F') || (colorHexValue.charAt(i) >= 'a' && colorHexValue.charAt(i) <= 'f')){
					continue;
				}
				else {
					throw new IllegalArgumentException("This is an invalid hexadecimal value.");
				}
			}
			else {
				throw new IllegalArgumentException("This is an invalid hexadecimal value.");
			}
		}
		this.colorHexValue= colorHexValue;
	}
	/**
	 * Creates a Color object using the color's hexadecimal value and color name
	 * by using the first constructor
	 * 
	 * @param colorHexValuea string in the format of #XXXXXX where X represents a digit or letter between A and F
	 * @param colorName a string of the color's name
	 * @throws IllegalArgumentException exception is thrown when passed an invalid hexadecimal value
	 */
	public Color ( String colorHexValue, String colorName ) throws IllegalArgumentException{
		//calls the previous constructor to check the hex value and then set the hex value and color name is passed
		this(colorHexValue);
		this.colorName=colorName;
	}
	/**
	 * Creates a color object using a color's RGB values after checking to see if they are valid
	 * 
	 * @param red the integer that represents red in RGB
	 * @param green the integer that represents green in RGB
	 * @param blue the integer that represents blue in RGB
	 * @throws IllegalArgumentException exception is thrown when RGB value is not valid
	 */
	public Color ( int red, int green, int blue ) throws IllegalArgumentException{
		//RGB is between 0 and 255 inclusive so we check if the RGB value is between those two numbers
		if (red>=0 && red<=255) {
			this.red=red;
		}
		else {
			throw new IllegalArgumentException("Input must be an integer between 0 and 255.");
		}
		if (green>=0 && green<=255) {
			this.green=green;
		}
		else {
			throw new IllegalArgumentException("Input must be an integer between 0 and 255.");
		}
		if (blue>=0 && blue<=255) {
			this.blue=blue;
		}
		else {
			throw new IllegalArgumentException("Input must be an integer between 0 and 255.");
		}
	}
	/**
	 * This returns the RGB value for red unless the hex value is null
	 * @return the integer representing red in RGB
	 */
	int getRed() {
		//if the hex value is null then there is no value to convert so it stays a 0
		if(colorHexValue==null) {
			return 0;
		}
		else {
			//sets red to the converted hex value
			red=hexToRed(colorHexValue);
		}
		return red;
	}
	/**
	 * This returns the RGB value for green unless the hex value is null
	 * @return the integer representing green in RGB
	 */
	int getGreen() {
		//if the hex value is null then there is no value to convert so it stays a 0
		if(colorHexValue==null) {
			return 0;
		}
		else {
			//sets green to the converted hex value
			green=hexToGreen(colorHexValue);
		}
		return green;
	}
	/**
	 * This returns the RGB value for blue unless the hex value is null
	 * @return the integer representing blue in RGB
	 */
	int getBlue() {
		//if the hex value is null then there is no value to convert so it stays a 0
		if(colorHexValue==null) {
			return 0;
		}
		else {
			//sets blue to the converted hex value
			blue=hexToBlue(colorHexValue);
		}
		return blue;
	}
	/**
	 * This will return the color's name
	 * @return the color's name
	 */
	String getName() {
		return colorName;
	}
	/**
	 * This will convert the RGB values back to hexadecimal values and formatting them properly
	 * @return a string of a hexadecimal value
	 */
	String getHexValue() {
		//Converts the RGB value to hex value and adds a 0 is it lacks a 0
		String redHexValue=Integer.toHexString(this.red);
		if (redHexValue.length()!=2) {
			redHexValue="0"+redHexValue;
		}
		String greenHexValue=Integer.toHexString(this.green);
		if (greenHexValue.length()!=2) {
			greenHexValue="0"+greenHexValue;
		}
		String blueHexValue=Integer.toHexString(this.blue);
		if (blueHexValue.length()!=2) {
			blueHexValue="0"+blueHexValue;
		}
		String rgbToHex;
		try {
			//if the null check throws an exception we know we know to reformat the hex values
			boolean nullChecker = this.colorHexValue.equals(null);
			if (nullChecker) {
				return colorHexValue;
			}
		}
		//if exception is thrown it reformats the hex value and returns colorHexValue
		catch (NullPointerException e) {
			redHexValue = String.format("%2s", redHexValue.replaceAll(" ","0"));
			greenHexValue = String.format("%2s", greenHexValue.replaceAll(" ","0"));
			blueHexValue = String.format("%2s", blueHexValue.replaceAll(" ","0"));
			rgbToHex = ("#"+redHexValue+greenHexValue+blueHexValue);
			return rgbToHex.toUpperCase();
		}
		return colorHexValue;
	}
	/**
	 * This method converts a particular value in the hexadecimal value into a form, because some
	 * values will be letters, we can use to convert hexadecimal values to RGB values
	 * 
	 * @param hexValue the string of the hexadecimal value that we are trying to convert
	 * @param index the particular index of the hexadecimal string we want to use
	 * @return an integer value of the particular index of the hexadecimal string
	 */
	private int hexToNum (String hexValue, int index) {
		int num = 0;
		//changed hex value to upper casefor comparisons
		hexValue=hexValue.toUpperCase();
		//if the hex value is a digit we leave it as is
		if (Character.isDigit(hexValue.charAt(index))) {
			num= Character.getNumericValue(hexValue.charAt(index));
		}
		//if hex value is a letter we assign the appropriate integer value of the letter
		else if (hexValue.charAt(index)=='A') {
			num=10;
		}
		else if (hexValue.charAt(index)=='B') {
			num=11;
		}
		else if (hexValue.charAt(index)=='C') {
			num=12;
		}
		else if (hexValue.charAt(index)=='D') {
			num=13;
		}
		else if (hexValue.charAt(index)=='E') {
			num=14;
		}
		else if (hexValue.charAt(index)=='F') {
			num=15;
		}
		//return the integer hex value
		return num;
	}
	/**
	 * The method will convert the first two values of the hexadecimal value after the #
	 * to the red RGB value
	 * @param hexValue the string of hexadecimal value we want to convert
	 * @return the integer that represents red in the RGB values
	 */
	private int hexToRed (String hexValue) {
		//for conversions take first number times 16 and add the second number
		int num1=hexToNum(hexValue, 1);
		int num2=hexToNum(hexValue, 2);
		int result=(num1*16)+num2;
		return result;
	}
	/**
	 * The method will convert the hexadecimal value to green by looking at the 3rd and fourth index
	 * @param hexValue the string of hexadecimal value we want to convert
	 * @return the integer that represents green in the RGB values
	 */
	private int hexToGreen (String hexValue) {
		//for conversions take first number times 16 and add the second number
		int num1=hexToNum(hexValue, 3);
		int num2=hexToNum(hexValue, 4);
		int result=(num1*16)+num2;
		return result;
	}
	/**
	 * The method will convert the hexadecimal value to blue by looking at the 5th and 6th index
	 *@param hexValue the string of hexadecimal value we want to convert
	 * @return the integer that represents blue in the RGB values
	 */
	private int hexToBlue (String hexValue) {
		//for conversions take first number times 16 and add the second number
		int num1=hexToNum(hexValue, 5);
		int num2=hexToNum(hexValue, 6);
		int result=(num1*16)+num2;
		return result;
	}
	@Override
	/**
	 * Checks if two Color objects are equal regardless of the case (lower or upper)
	 * @param obj the color object being compared
	 * return will return true or false based on comparison
	 */
	public boolean equals(Object obj) {
		//if the object is a color then we compare to see if the hex values are the same while ignoring case
		if (obj instanceof Color) {
			if(this.colorHexValue.equalsIgnoreCase(((Color) obj).getHexValue())) {
				return true;
			}
			else {
				return false;
			}
		}
		else {
			return false;
		}
	}
	@Override
	/**
	 * Correctly formats the strings that must be in the string and returns a string that
	 * that includes the hexadecimal value, the RGB value, and the color name if there is any
	 * return the string with all the color information
	 */
	public String toString() {
		//converts the integer RGB values to string
		String redNum=Integer.toString(hexToRed(colorHexValue));
		String greenNum=Integer.toString(hexToGreen(colorHexValue));
		String blueNum=Integer.toString(hexToBlue(colorHexValue));
		//add spaces to correct format
		if (redNum.length()==2) {
			redNum=" "+redNum;
		}
		if (greenNum.length()==2) {
			greenNum=" "+greenNum;
		}
		if (blueNum.length()==2) {
			blueNum=" "+blueNum;
		}
		if (redNum.length()==1) {
			redNum="  "+redNum;
		}
		if (greenNum.length()==1) {
			greenNum="  "+greenNum;
		}
		if (blueNum.length()==1) {
			blueNum="  "+blueNum;
		}
		//if color name is null or blank we return a string without color name
		if (this.colorName==null) {
			return(this.colorHexValue.toUpperCase()+", ("+redNum+","+greenNum+","+blueNum+")\n");
		}
		//if color name is given then we return string with it
		else {
			return(this.colorHexValue.toUpperCase()+", ("+redNum+","+greenNum+","+blueNum+")"+", "+this.colorName+"\n");
		}
	}
	@Override
	/**
	 * Compares a Color object
	 * return the integer value result of the comparison
	 */
	public int compareTo(Color arg0) {
		//we compare while ignoring the case
		int compare = this.colorHexValue.compareToIgnoreCase(arg0.colorHexValue);
		return compare;
	}
}
