package project2;
/**
 * This class provides a singly linked list implementation of the OrderedList<E> interface.
 * The  elements are sorted as well.
 * 
 * @author Alice Han
 *
 * @param <E>
 */
public class OrderedLinkedList<E extends Comparable<E>> implements OrderedList<E>, Cloneable{
	//Created a constructor that creates this ordered linked list
	OrderedLinkedList(){
		
	}

	//Node class copied from 3.2.1 in lecture notes and textbook page 126
	private class Node<E>{
		private E data;
		
		private Node<E> next;
		
		public Node(E e, Node<E>n) {
			data=e;
			next=n;
		}

		public E getData() {
			return data;
		}
		
		public Node<E> getNext(){
			return next;
		}
		
		public void setData (E data) {
			this.data = data;
		}
		public void setNext (Node<E> next) {
			this.next = next;
		}
	}
	//Create the variables for head and initialize size
	private Node<E> head;
	private int size=0;
	
	/**
     * Adds the specified element to  this list in a sorted order. 
     *
     * <p>The element added must implement Comparable<E> interface. This list 
     * does not permit null elements. 
     *
     * @param e element to be appended to this list
     * @return <tt>true</tt> if this collection changed as a result of the call
     * @throws ClassCastException if the class of the specified element
     *         does not implement Comparable<E> 
     * @throws NullPointerException if the specified element is null
     */
	@Override
	public boolean add(E e) throws ClassCastException, NullPointerException{
		//if the specified element is null we throw an exception
		if(e==null) {
			throw new NullPointerException();
		}
		//Create a new node so we can compare e to other nodes
		Node<E> eAsNode=new Node<E>(e, null);
		eAsNode.setData(e);
		//If the head is empty we set the head to our element and increment size
		if (head==null) {
			head=eAsNode;
			size++;
			return true;
		}
		//Created nodes to have a reference to a node as we move down a list
		Node<E> prev=head;
		Node<E> current = head.getNext();
		//If e is less than the head we set e as the head and increment size
		if(head.getData().compareTo(e)>0) {
			eAsNode.setNext(head);
			head=eAsNode;
			size++;
			return true;
		}
		//while the next element is not a null, while not at the tail, we run this loop
		while(current!=null) {
			//if e is less than the element we are looking at we add e to the list
			if(current.getData().compareTo(e)>0){
				eAsNode.setNext(current);
				prev.setNext(eAsNode);
				size++;
				return true;
			}
			//If the add does not happen, we move down the list to the next node
			prev=prev.getNext();
			current=current.getNext();
		}
		//If we reach the end of the list and need to add e
		//then we set the tail element to e
		prev.setNext(eAsNode);
		size++;
		return true;
	}

	/**
     * Removes all of the elements from this list.
     * The list will be empty after this call returns.
     */
	@Override
	public void clear() {
		head=null;
		size=0;
	}

	/**
     * Returns <tt>true</tt> if this list contains the specified element.
     *
     * @param o element whose presence in this list is to be tested
     * @return <tt>true</tt> if this list contains the specified element
     * @throws ClassCastException if the type of the specified element
     *         is incompatible with this list
     * @throws NullPointerException if the specified element is null 
     */
	@Override
	public boolean contains(Object o) throws ClassCastException, NullPointerException{
		//If the specified element is null we throw exception
		if (o==null) {
			throw new NullPointerException();
		}
		//If o is not compatible with this list then we throw exception
		if (o instanceof OrderedLinkedList) {
			throw new ClassCastException();
		}
		//if the list is empty we return false
		if (head==null) {
			return false;
		}
		Node<E> current=head;
		//if the head's data is equal to o we return true
		if(head.getData().equals(o)) {
			return true;
		}
		//We run a while loop and check if any of the elements are equal
		//to the element we are looking for
		while(current.getNext()!=null) {
			if(current.getData().equals(o)) {
				return true;
			}
			else {
				current=current.getNext();
			}
		}
		//If we reach the end of the list we check the tail
		if(current.getData().equals(o)) {
			return true;
		}
		return false;
	}
	
	/**
     * Returns the element at the specified position in this list.
     *
     * @param index index of the element to return
     * @return the element at the specified position in this list
     * @throws IndexOutOfBoundsException if the index is out of range 
     * <tt>(index < 0 || index >= size())</tt>
     */
	@Override
	public E get(int index) throws IndexOutOfBoundsException{
		Node<E> current=head;
		int counter=0;
		//Check if the index requested is out of bounds
		if (index<0||index>=size()) {
			throw new IndexOutOfBoundsException();
		}
		//As we raise counter we check to see if index matches counter
		//and if there's a match we return that node's element
		while(current.getNext()!=null) {
			if(counter==index) {
				return current.getData();
			}
			else {
				current=current.getNext();
				counter++;
			}
		}
		//The while loop doesn't account for the tail of the list so we check here
		if(current.getNext()==null) {
			return current.getData();
		}
		return null;
	}

	/**
     * Returns the index of the first occurrence of the specified element
     * in this list, or -1 if this list does not contain the element.
     *
     * @param o element to search for
     * @return the index of the first occurrence of the specified element in
     *         this list, or -1 if this list does not contain the element
     */
	@Override
	public int indexOf(Object o) {
		Node<E> current=this.head;
		int index=0;
		//Check through the list to see if the node's element is equal to the object
		//if so we return that node's index
		while(current!=null) {
			if (current.getData().equals(o)) {
				return index;
			}
			else {
				index++;
			}
			//Set the next current to continue to search through the list
			current=current.getNext();
		}
		//If not found we return -1
		return -1;
	}

	/**
     * Removes the element at the specified position in this list.  Shifts any
     * subsequent elements to the left (subtracts one from their indices if such exist).
     * Returns the element that was removed from the list.
     *
     * @param index the index of the element to be removed
     * @return the element previously at the specified position
     * @throws IndexOutOfBoundsException  if the index is out of range 
     * <tt>(index < 0 || index >= size())</tt>
     */
	@Override
	public E remove(int index) throws IndexOutOfBoundsException{
		//We throw exception if the index is out of bounds
		if (index < 0 || index >= size()) {
			throw new IndexOutOfBoundsException();
		}
		E returnElement = null;
		Node<E> current=head;
		int counter=1;
		//If the index is 0 we are returning the head add reduce the size by 1
		if(index==0 && current.next!=null) {
			returnElement=head.getData();
			head=current.getNext();
			size--;
			return returnElement;
		}
		//We will iterate through the list
		while(current.next.next!=null) {
			//If the index matches the counter we set the previous node to the
			//node after the current node and reduce size by 1
			if(counter==index) {
				returnElement=current.next.getData();
				current.next=current.next.next;
				size--;
				return returnElement;
			}
			//here we continue to move down the list if the above check failed
			else {
				current=current.next;
				counter++;
			}
		}
		//here we look to see if the tail is what we wish to remove
		if(index==counter) {
			returnElement=current.next.getData();
			current.next=null;
			size--;
		}
		return returnElement;
	}

	/**
     * Removes the first occurrence of the specified element from this list,
     * if it is present.  If this list does not contain the element, it is
     * unchanged.  More formally, removes the element with the lowest index
     * {@code i} such that
     * <tt>(o.equals(get(i))</tt>
     * (if such an element exists).  Returns {@code true} if this list
     * contained the specified element (or equivalently, if this list
     * changed as a result of the call).
     *
     * @param o element to be removed from this list, if present
     * @return {@code true} if this list contained the specified element
     * @throws ClassCastException if the type of the specified element
     *         is incompatible with this list
     * @throws NullPointerException if the specified element is null and this
     *         list does not permit null elements
     */
	@Override
	public boolean remove(Object o) throws ClassCastException, NullPointerException{
		//We throw an exception when the specified element is null
		if (o==null) {
			throw new NullPointerException();
		}
		//If the list is empty there is nothing to return so we return false
		if (head==null) {
			return false;
		}
		//If the type of the specified element is not compatible with the list we throw an exception
		if (o.getClass()!=head.getData().getClass()) {
			throw new ClassCastException();
		}
		//If the element we are looking for is in the head we remove the element
		Node<E> current = head;
		if(head.getData().equals(o)) {
			head=head.getNext();
			//reduce size by 1
			size--;
			return true;
		}
		//We look through the list to see if the element is in any of the nodes
		//if it is found then we set current's next to the node after the next
		while(current.getNext()!=null) {
			if(current.getData().equals(o)) {
				current.setNext(current.getNext().getNext());
				//reduce size by 1
				size--;
				return true;
			}
			//We set current to current's next to move along the list
			else {
				current=current.getNext();
			}
		}
		//If no changes are made we return false
		return false;
	}
	
	/**
     * Returns the number of elements in this list.
     *
     * @return the number of elements in this list
     */
	@Override
	public int size() {
		return this.size;
	}
	
	/**
     * Returns a shallow copy of this list. (The elements
     * themselves are not cloned.) 
     * This method copied from textbook section 3.6.2 page 144
     *
     * @return a shallow copy of this list instance
     * @throws CloneNotSupportedException - if the object's class does 
     *         not support the Cloneable interface
     */
	@Override
    public Object clone() throws CloneNotSupportedException{
		//Use object's clone method to make initial copy
		OrderedLinkedList<E>other=(OrderedLinkedList<E>) super.clone();
		//We will make independent chain of nodes
		if (size>0) {
			other.head=(OrderedLinkedList<E>.Node<E>) new Node<E>(head.getData(), null);
			Node<E> walk=head.getNext();// walk through remainder of original list
			Node<E> otherTail = other.head;// remember most recently created node
			while(walk!=null) {// make a new node storing same element
				Node<E> newest=(OrderedLinkedList<E>.Node<E>) new Node<E>(walk.getData(), null);
				otherTail.setNext(newest);// link previous node to this one
				otherTail=newest;
				walk=walk.getNext();
			}
		}
		return other;
    }
    
    /**
     * Compares the specified object with this list for equality.  Returns
     * {@code true} if and only if the specified object is also a list, both
     * lists have the same size, and all corresponding pairs of elements in
     * the two lists are <i>equal</i>.  (Two elements {@code e1} and
     * {@code e2} are <i>equal</i> if {@code e1.equals(e2)}.)  
     * In other words, two lists are defined to be
     * equal if they contain the same elements in the same order.<p>
     *Copied from textbook page 140 section 3.5 and changed to fit this assignment
     *
     * @param o the object to be compared for equality with this list
     * @return {@code true} if the specified object is equal to this list
     */
    @Override
    public boolean equals(Object o){
    	//None of the elements in the list will be null so o can't null
    	if(o==null) {
    		return false;
    	}
    	//Check if the type is the same if not return false
    	if (getClass( ) != o.getClass( )) {
    		return false;
    	}
    	//O as a OrderedLinkedList
    	OrderedLinkedList<E> other = (OrderedLinkedList<E>) o;
    	//The list, if equal, should have the same size
    	if (size != other.size) {
    		return false;
    	}
    	Node<E> current = head; // traverse the primary list
    	Node<E> oCurrent = other.head; // traverse the secondary list
    	while (current != null) {
    		//check to see if they match
    		if (!current.getData( ).equals(oCurrent.getData( ))) {
    			return false;
    		}
    		current = current.getNext( );
    		oCurrent = oCurrent.getNext( );
    	}
    	return true; // if we reach this, everything matched successfully
    	}
    	
    
    /**
     * Returns a string representation of this list.  The string
     * representation consists of a list of the list's elements in the
     * order they are stored in this list, enclosed in square brackets
     * (<tt>"[]"</tt>).  Adjacent elements are separated by the characters
     * <tt>", "</tt> (comma and space).  Elements are converted to strings 
     * by the {@code toString()} method of those elements.
     *
     * @return a string representation of this list
     */
    @Override
    public String toString() {
    	//The format will look like [element,element,element]
    	String returnedString="[";
    	String addedString="";//string to be added
    	//We add the head if there is an element
    	if(head!=null) {
    		//We use the object's toString to convert the element into a string
    		addedString=head.getData().toString();
    		returnedString+=addedString;
    		//After the string is added we check to see if there will be more to add
    		if(head.getNext()!=null) {
    			returnedString+=", ";
    		}
    	}
    	//If the head is the only element we need to add we finisht the string and return it
    	else {
    		returnedString+="]";
    		return returnedString;
    	}
    	Node<E> current=head.getNext();
    	//Here we walk through the list if there is more to add and add if there is an element
    	while(current!=null) {
    		addedString=current.getData().toString();
   			returnedString+=addedString;
   			current=current.getNext();
   			//If the next element exist we add a comma to separate the list
   			if(current!=null) {
   				returnedString+=", ";
   			}
    	}
    	returnedString+="]";
    	return returnedString;//return finished string
    }
}
