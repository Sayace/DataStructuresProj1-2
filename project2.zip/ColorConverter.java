package project2;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * The ColorConverter class contains the main method which will open the file, read file,
 * store information, obtain user input, and also handles exceptions
 * 
 * @author Alice Han
 *
 */

public class ColorConverter {
	public static void main(String args[]) throws Exception {
		//if the argument is not given then we print out error message and exit
		if (args.length==0) {
			System.err.println("Error: file name needed as an argument");
			System.exit(0);
		}
		//create the new file object
		File file = new File(args[0]);
		//if the does not exist we print out the error message
	    if (!file.exists()){
			System.err.println(args[0]+ ": This file does not exist");
			System.exit(1);
		}
	    //we create Scanner and ColorList
	    Scanner in=null;
	    ColorList list = new ColorList();
	    //We try to make a new file and if an exception is thrown then we catch
	    try {
	    	in = new Scanner(file);
	    }
	    //if the file is not found we use the FileNotFoundException and print out an error message
	    catch (FileNotFoundException e1){
	    	System.err.print("Error: File not found.");
	    	System.exit(0);
	    }
	  //if the file cannot be read we use the IllegalStateException and print out an error message
	    catch (IllegalStateException e2) {
	    	System.err.print("Error: File cannot be read.");
	    	System.exit(0);
	    }
	    finally {
	    	//if the try passes then we read through the file until there is no next line
			while (in.hasNextLine()){
				//create a string to store the line of text
		    	String line = in.nextLine();
		    	//split the line using the comma
		    	String[] namesAndHex  = line.split(",");
		    	//if the namesAndHex does not equal 2 we continue the program
		    	if (namesAndHex.length != 2 ) {
		    		continue;
		    	}
		    	//we trim out the extra spaces around the names and hex
				namesAndHex[0] = namesAndHex[0].trim();
				namesAndHex[1] = namesAndHex[1].trim();
				//creates new color object to add to a ColorList
			    Color colors = new Color(namesAndHex[1], namesAndHex[0]);
			    list.add(colors);
	    	}
	    }
	    //close this scanner
	    in.close();
	    
	    //Create new scanner object to read user input
	    Scanner userIn= new Scanner(System.in);
	    //created two check booleans
	    boolean checker=true;
	    boolean newCheck=false;
	    //created a new Color object
	    Color testColor;
	    while (checker) {
	    	//Print out user prompt
		    System.out.println("Enter the color in HEX format (#RRGGBB) or \"quit\" to stop:");
		    //stores user input into string
		    String userInput=userIn.next();
		    //if user wants to quit we let the program end
		    if (userInput.equals("quit")) {
		    	checker=false;
		    	continue;
		    }
		  //try to create new Color object to test the user input
		    try {
		    	testColor= new Color(userInput);
		    }
		    //if the user input is not valid we catch and print error message
	    	catch (IllegalArgumentException e) {
	    		System.err.println("\nError: This is not a valid color specification.\n\n");
	    		continue;
	    	}
		    if(!userInput.equals("quit")) {
			    //if user inputs a proper hexadecimal value we look through the ColorList we made
			    //to find the and return the color information
			    for (int i=0; i<list.size(); i++) {
			   		Color currentColor = list.get(i);
					if (currentColor.getHexValue().equals(userInput)) {
			    		System.out.println("\nColor information:");
		    			System.out.println(list.get(i).toString());
		    			newCheck=true;
		    		}
		   		}
			  //if the hexadecimal value is not found we print a friendly message to let user know
		    	if (newCheck) {
		    		continue;
		    	}
				else {
		   			System.out.println("\nThat color could not be found in this file.\n");
		   		}
		    }
	    }
	    //close the scanner
	    userIn.close();
    }
}

