package project2;

/**
 * The ColorList class stores Color objects
 * We use it to store hexadecimal values and color names
 * 
 * @author Alice Han
 *
 */

public class ColorList extends OrderedLinkedList<Color>{
	/**
	 * Creates a color list using the OrderedLinkedList class
	 */
	public ColorList ( ) {
		super();
	}
	/**
	 * This method returns the color object from the list by color name
	 * @param colorName the color name we are looking for
	 * @return the color object
	 */
	public Color getColorByName ( String colorName ) {
		//if the color object we are checking has a null name then we return null
		for (int i=0; i<this.size(); i++) {
			if(this.get(i).getName()==null) {
				if (colorName==null) {
					return this.get(i);
				}
			}
			//if the color name is not null we return the color name
			else if (this.get(i).getName().equalsIgnoreCase(colorName)) {
				return this.get(i);
			}
		}
		//if not found return null
		return null;
	}
	/**
	 * This method returns the color object from the list by color hex value
	 * @param colorHexValue the color ehx value we are looking for
	 * @return the color object
	 */
	public Color getColorByHexValue ( String colorHexValue ) {
		//we looked through the list for the hex value
		for (int i=0; i<this.size(); i++) {
			if (this.get(i).getHexValue().equalsIgnoreCase(colorHexValue)) {
				return this.get(i);
			}
		}
		//if not found return null
		return null;
	}

}
